#pragma once

//#include <Windows.h>
// una de las siguientes dos l�neas seg�n la organizaci�n del proyecto

#include "glad.h"
#include <GL/freeglut.h> // OpenGL Utility Toolkit
#include <glm.hpp> // OpenGL Mathematics
//#include "GLinclude.h"